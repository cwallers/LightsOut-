﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace GUIModalDialogBox
{
    partial class ModalDialogBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.greetinglbl = new Label();
            this.greetingcbx = new ComboBox();
            this.nounlbl = new Label();
            this.nountbx = new TextBox();
            this.showGreetingchbx = new CheckBox();
            this.showNamechbx = new CheckBox();
            this.endPunctuationchbx = new CheckBox();
            this.okbtn = new Button();
            this.cancelbtn = new Button();
            this.SuspendLayout();
            // 
            // greetinglbl
            // 
            this.greetinglbl.AutoSize = true;
            this.greetinglbl.Location = new Point(25, 28);
            this.greetinglbl.Name = "greetinglbl";
            this.greetinglbl.Size = new Size(50, 13);
            this.greetinglbl.TabIndex = 0;
            this.greetinglbl.Text = "Greeting:";
            // 
            // greetingcbx
            // 
            this.greetingcbx.DropDownStyle = ComboBoxStyle.DropDownList;
            this.greetingcbx.FormattingEnabled = true;
            this.greetingcbx.Items.AddRange(new object[] {
            "Hello",
            "Welcome",
            "Hi"});
            this.greetingcbx.Location = new Point(95, 25);
            this.greetingcbx.Name = "greetingcbx";
            this.greetingcbx.Size = new Size(160, 21);
            this.greetingcbx.TabIndex = 1;
            // 
            // nounlbl
            // 
            this.nounlbl.AutoSize = true;
            this.nounlbl.Location = new Point(25, 79);
            this.nounlbl.Name = "nounlbl";
            this.nounlbl.Size = new Size(41, 13);
            this.nounlbl.TabIndex = 2;
            this.nounlbl.Text = "Name: ";
            // 
            // nountbx
            // 
            this.nountbx.Location = new Point(95, 76);
            this.nountbx.Name = "nountbx";
            this.nountbx.Size = new Size(160, 20);
            this.nountbx.TabIndex = 3;
            // 
            // showGreetingchbx
            // 
            this.showGreetingchbx.AutoSize = true;
            this.showGreetingchbx.Location = new Point(28, 124);
            this.showGreetingchbx.Name = "showGreetingchbx";
            this.showGreetingchbx.Size = new Size(94, 17);
            this.showGreetingchbx.TabIndex = 5;
            this.showGreetingchbx.Text = "Show greeting";
            this.showGreetingchbx.UseVisualStyleBackColor = true;
            // 
            // showNamechbx
            // 
            this.showNamechbx.AutoSize = true;
            this.showNamechbx.Location = new Point(28, 163);
            this.showNamechbx.Name = "showNamechbx";
            this.showNamechbx.Size = new Size(82, 17);
            this.showNamechbx.TabIndex = 6;
            this.showNamechbx.Text = "Show name";
            this.showNamechbx.UseVisualStyleBackColor = true;
            // 
            // endPunctuationchbx
            // 
            this.endPunctuationchbx.AutoSize = true;
            this.endPunctuationchbx.Location = new Point(151, 124);
            this.endPunctuationchbx.Name = "endPunctuationchbx";
            this.endPunctuationchbx.Size = new Size(104, 17);
            this.endPunctuationchbx.TabIndex = 7;
            this.endPunctuationchbx.Text = "End punctuation";
            this.endPunctuationchbx.UseVisualStyleBackColor = true;
            // 
            // okbtn
            // 
            this.okbtn.DialogResult = DialogResult.OK;
            this.okbtn.Location = new Point(47, 215);
            this.okbtn.Name = "okbtn";
            this.okbtn.Size = new Size(75, 23);
            this.okbtn.TabIndex = 8;
            this.okbtn.Text = "OK";
            this.okbtn.UseVisualStyleBackColor = true;
            this.okbtn.Click += new EventHandler(this.okbtn_Click);
            // 
            // cancelbtn
            // 
            this.cancelbtn.DialogResult = DialogResult.Cancel;
            this.cancelbtn.Location = new Point(172, 215);
            this.cancelbtn.Name = "cancelbtn";
            this.cancelbtn.Size = new Size(75, 23);
            this.cancelbtn.TabIndex = 9;
            this.cancelbtn.Text = "Cancel";
            this.cancelbtn.UseVisualStyleBackColor = true;
            this.cancelbtn.Click += new EventHandler(this.cancelbtn_Click);
            // 
            // ModalDialogBox
            // 
            this.AutoScaleDimensions = new SizeF(6F, 13F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(284, 262);
            this.Controls.Add(this.cancelbtn);
            this.Controls.Add(this.okbtn);
            this.Controls.Add(this.endPunctuationchbx);
            this.Controls.Add(this.showNamechbx);
            this.Controls.Add(this.showGreetingchbx);
            this.Controls.Add(this.nountbx);
            this.Controls.Add(this.nounlbl);
            this.Controls.Add(this.greetingcbx);
            this.Controls.Add(this.greetinglbl);
            this.Name = "ModalDialogBox";
            this.Text = "ModalDialogBox";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label greetinglbl;
        private ComboBox greetingcbx;
        private Label nounlbl;
        private TextBox nountbx;
        private CheckBox showGreetingchbx;
        private CheckBox showNamechbx;
        private CheckBox endPunctuationchbx;
        private Button okbtn;
        private Button cancelbtn;
    }
}