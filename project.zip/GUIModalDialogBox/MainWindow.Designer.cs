﻿namespace GUIModalDialogBox
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.greetinglbl = new System.Windows.Forms.Label();
            this.stringlbl = new System.Windows.Forms.Label();
            this.changeTextbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // greetinglbl
            // 
            this.greetinglbl.AutoSize = true;
            this.greetinglbl.Location = new System.Drawing.Point(48, 33);
            this.greetinglbl.Name = "greetinglbl";
            this.greetinglbl.Size = new System.Drawing.Size(31, 13);
            this.greetinglbl.TabIndex = 0;
            this.greetinglbl.Text = "Hello";
            // 
            // stringlbl
            // 
            this.stringlbl.AutoSize = true;
            this.stringlbl.Location = new System.Drawing.Point(90, 58);
            this.stringlbl.Name = "stringlbl";
            this.stringlbl.Size = new System.Drawing.Size(24, 13);
            this.stringlbl.TabIndex = 1;
            this.stringlbl.Text = "text";
            // 
            // changeTextbtn
            // 
            this.changeTextbtn.Location = new System.Drawing.Point(74, 106);
            this.changeTextbtn.Name = "changeTextbtn";
            this.changeTextbtn.Size = new System.Drawing.Size(108, 23);
            this.changeTextbtn.TabIndex = 2;
            this.changeTextbtn.Text = "Change Text";
            this.changeTextbtn.UseVisualStyleBackColor = true;
            this.changeTextbtn.Click += new System.EventHandler(this.changeTextbtn_Click);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(260, 153);
            this.Controls.Add(this.changeTextbtn);
            this.Controls.Add(this.stringlbl);
            this.Controls.Add(this.greetinglbl);
            this.Name = "MainWindow";
            this.Text = "Main Window";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label greetinglbl;
        private System.Windows.Forms.Label stringlbl;
        private System.Windows.Forms.Button changeTextbtn;
    }
}

