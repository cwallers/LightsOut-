﻿using System;
using System.Windows.Forms;

namespace GUIModalDialogBox
{
    public partial class ModalDialogBox : Form
    {
        public bool ShowName;
        public bool ShowGreeting;
        public bool ShowPunctuation;
        public string GreetingName;
        public Salutation Greeting;

        public enum Salutation
        {
            Hello,
            Welcome,
            Hi
        };

        public ModalDialogBox()
        {
            InitializeComponent();
        }

        private void okbtn_Click(object sender, EventArgs e)
        {
            ShowName = showNamechbx.Checked;
            ShowGreeting = showGreetingchbx.Checked;
            ShowPunctuation = endPunctuationchbx.Checked;
            GreetingName = nountbx.Text;
            Greeting = ((string)greetingcbx.SelectedItem == "Hello")
                ? Salutation.Hello 
                : ((string)greetingcbx.SelectedItem == "Hi")
                    ? Salutation.Hi 
                    : Salutation.Welcome;
        }

        private void cancelbtn_Click(object sender, EventArgs e)
        {
            showNamechbx.Checked = ShowName;
            showGreetingchbx.Checked = ShowGreeting;
            endPunctuationchbx.Checked = ShowPunctuation;
            nountbx.Text = GreetingName;
            greetingcbx.SelectedItem = (Greeting == Salutation.Hello)
                ? "Hello"
                : (Greeting == Salutation.Hi)
                    ? "Hi"
                    : "Welcome";
        }
    }
}
