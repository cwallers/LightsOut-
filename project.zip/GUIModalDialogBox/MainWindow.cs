﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIModalDialogBox
{
    public partial class MainWindow : Form
    {

        private ModalDialogBox OptionsForm;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void changeTextbtn_Click(object sender, EventArgs e)
        {
            if (OptionsForm == null)
            {
                OptionsForm = new ModalDialogBox();
                OptionsForm.ShowName = true;
                OptionsForm.ShowGreeting = true;
                OptionsForm.ShowPunctuation = true;
                OptionsForm.Name = "World";
                OptionsForm.Greeting = ModalDialogBox.Salutation.Hello;
            }
            if (OptionsForm.ShowDialog(this) == DialogResult.OK) // OK
            {
                stringlbl.Visible = OptionsForm.ShowName;
                greetinglbl.Visible = OptionsForm.ShowGreeting;

                greetinglbl.Text = OptionsForm.Greeting.ToString();
                stringlbl.Text = OptionsForm.GreetingName;

                if (OptionsForm.ShowPunctuation)
                {
                    stringlbl.Text += "!";
                }

            }
            else 
            {
                // Cancel -- don't do anything
            }
        }
    }
}
